﻿using Microsoft.Extensions.Caching.Memory;
using SantanderAPI.Models;

namespace SantanderAPI.Service
{
    public class HackerNewsService
    {

        private readonly HttpClient _httpClient;
        private readonly IMemoryCache _cache;

        public HackerNewsService(HttpClient httpClient, IMemoryCache cache)
        {
            _httpClient = httpClient;
            _cache = cache;
        }

        public async Task<List<Story>> GetBestStoriesAsync(int count)
        {
            if (!_cache.TryGetValue("bestStories", out List<int> storyIds))
            {
                storyIds = await _httpClient.GetFromJsonAsync<List<int>>("https://hacker-news.firebaseio.com/v0/beststories.json");
                _cache.Set("bestStories", storyIds, TimeSpan.FromMinutes(10)); // Cache for 10 minutes
            }

            var stories = new List<Story>();

            foreach (var storyId in storyIds.Take(count))
            {
                var story = await _httpClient.GetFromJsonAsync<Story>($"https://hacker-news.firebaseio.com/v0/item/{storyId}.json");
                stories.Add(story);
            }

            return stories.OrderByDescending(s => s.Score).ToList();
        }
    }
}
