﻿using Microsoft.AspNetCore.Mvc;
using SantanderAPI.Service;

namespace SantanderAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StoriesController : ControllerBase
    {

        private readonly HackerNewsService _hackerNewsService;

        public StoriesController(HackerNewsService hackerNewsService)
        {
            _hackerNewsService = hackerNewsService;
        }

        [HttpGet("best")]
        public async Task<IActionResult> GetBestStories(int n)
        {
            var stories = await _hackerNewsService.GetBestStoriesAsync(n);
            return Ok(stories);
        }

    }
}
